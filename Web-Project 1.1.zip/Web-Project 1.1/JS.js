// An array to store the items in the cart
var cart = [];

// An array to store the items that have been bought
var boughtItems = [];

// Function to add an item to the cart
let buttons=document.querySelectorAll(".buy-product");
buttons.forEach(function(button){
    button.addEventListener("click", function(event){
        const input = event.target.previousElementSibling.value;
        console.log(event.target.dataset , input);
        let price=event.target.dataset.price;
        let name=event.target.dataset.name;
        let quantity=input;
        addToCart(name, quantity, price);

    });

});

function addToCart(name, quantity, price) {
  cart=[];                ////////////////////////////////
  var newItem = {};
  newItem.name = name;
  newItem.quantity = quantity;
  newItem.price = price;
  cart.push(newItem);
  let intial=[];
  try {
    intial=JSON.parse(localStorage.getItem("cart"))||[];
  } catch (error) {
    intial=[];
  };
  localStorage.setItem("cart",JSON.stringify(intial.concat(cart)));
};


function updatecart(){
    var update=JSON.parse(localStorage.getItem("cart"));
    let total=0, totalAmount=0;
    update.forEach(function(cartItem){
        const price=cartItem.price;
        const quantity= parseInt(cartItem.quantity); ///////////////////
        const itemTotal= parseFloat(quantity*price);
        total+=itemTotal;
        totalAmount+=quantity;   
    });
    rendertotal(total , totalAmount);
};

function rendertotal(total , totalAmount){
const totalElements= document.getElementById("total");
totalElements.innerHTML=`$ ${total}`;
const totalAmountElement= document.getElementById("totalAmount");
totalAmountElement.innerHTML=`Number of Items Selected: ${totalAmount}`;

};

function buyProduct(){
    rendertotal(0,0);
    localStorage.removeItem("cart");
};







////////////////////////////////////////////////

////////////////////////////////////////////////
function buyProduct1(){
  // Get the items in the cart from local storage
  var cart = JSON.parse(localStorage.getItem("cart"));
  // Add the items in the cart to the boughtItems array
  cart.forEach(function(item) {
    boughtItems.push(item.name+ " "+ item.quantity+ " Grams " + " ( $" + item.price + " Per Gram) "
    +"Total = "+ item.price*item.quantity);
  });
  // Render each item in the boughtItems array as a p element
  boughtItems.forEach(function(item) {
    renderproduct(item);
  });
  // Clear the cart in local storage
  localStorage.removeItem("cart");
  // Reset the cart and the total amount and total elements in the HTML
  
}
function renderproduct (newItem){
  var pElement = document.createElement("p");
  pElement.id="newElement";
  pElement.textContent = newItem;
  var container = document.getElementById("boughtItems");
  container.appendChild(pElement);


};
